package AE1;

public class ae1ej6 {

	public static void main(String[] args) {
		
		App app = new App();
		app.sumaInversa();

	}

}
